// EjemploHerencia.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"
#include <iostream>
#include "Rectangulo.h"
#include "Paralelogramo.h"
#include "conio.h"

using namespace std;

int main(void) {
   Rectangulo Rect;
   Paralelogramo Par;
 
   Rect.setWidth(5);
   Rect.setHeight(7);
   
   Par.setWidth(6);
   Par.setHeight(9);

   // Muestra el �rea de un rectangulo
   cout << " Area Rectangulo: " << Rect.getArea() << endl;

   cout<<" Area Paralelogramo: "<< Par.getArea()<<endl;
   getch();
   return 0;
}