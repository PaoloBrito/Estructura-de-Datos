#include "StdAfx.h"
#include "Paralelogramo.h"


Paralelogramo::Paralelogramo(void)
{
}


Paralelogramo::~Paralelogramo(void)
{
}
