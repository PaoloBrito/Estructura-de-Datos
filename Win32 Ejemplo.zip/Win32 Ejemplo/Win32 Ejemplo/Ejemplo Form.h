#pragma once

namespace Win32Ejemplo {

	using namespace System;
	using namespace System::ComponentModel;
	using namespace System::Collections;
	using namespace System::Windows::Forms;
	using namespace System::Data;
	using namespace System::Drawing;

	/// <summary>
	/// Summary for EjemploForm
	/// </summary>
	public ref class EjemploForm : public System::Windows::Forms::Form
	{
	public:
		EjemploForm(void)
		{
			InitializeComponent();
			//
			//TODO: Add the constructor code here
			//
		}

	protected:
		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		~EjemploForm()
		{
			if (components)
			{
				delete components;
			}
		}
	private: System::Windows::Forms::Button^  buttonresta;
	private: System::Windows::Forms::Button^  buttonmulti;
	protected: 


	private: System::Windows::Forms::Button^  buttonsuma;
	private: System::Windows::Forms::Button^  buttondivi;


	private: System::Windows::Forms::RichTextBox^  PrimerNumero;
	private: System::Windows::Forms::RichTextBox^  SegundoNumero;
	private: System::Windows::Forms::RichTextBox^  Respuesta;



	private: System::Windows::Forms::Label^  label1;
	private: System::Windows::Forms::Label^  label2;
	private: System::Windows::Forms::Label^  label3;
	protected: 

	private:
		/// <summary>
		/// Required designer variable.
		/// </summary>
		System::ComponentModel::Container ^components;

#pragma region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		void InitializeComponent(void)
		{
			this->buttonresta = (gcnew System::Windows::Forms::Button());
			this->buttonmulti = (gcnew System::Windows::Forms::Button());
			this->buttonsuma = (gcnew System::Windows::Forms::Button());
			this->buttondivi = (gcnew System::Windows::Forms::Button());
			this->PrimerNumero = (gcnew System::Windows::Forms::RichTextBox());
			this->SegundoNumero = (gcnew System::Windows::Forms::RichTextBox());
			this->Respuesta = (gcnew System::Windows::Forms::RichTextBox());
			this->label1 = (gcnew System::Windows::Forms::Label());
			this->label2 = (gcnew System::Windows::Forms::Label());
			this->label3 = (gcnew System::Windows::Forms::Label());
			this->SuspendLayout();
			// 
			// buttonresta
			// 
			this->buttonresta->Location = System::Drawing::Point(111, 157);
			this->buttonresta->Name = L"buttonresta";
			this->buttonresta->Size = System::Drawing::Size(75, 23);
			this->buttonresta->TabIndex = 0;
			this->buttonresta->Text = L"Resta";
			this->buttonresta->UseVisualStyleBackColor = true;
			// 
			// buttonmulti
			// 
			this->buttonmulti->Location = System::Drawing::Point(101, 186);
			this->buttonmulti->Name = L"buttonmulti";
			this->buttonmulti->Size = System::Drawing::Size(95, 23);
			this->buttonmulti->TabIndex = 1;
			this->buttonmulti->Text = L"Multiplicacion";
			this->buttonmulti->UseVisualStyleBackColor = true;
			// 
			// buttonsuma
			// 
			this->buttonsuma->Location = System::Drawing::Point(111, 128);
			this->buttonsuma->Name = L"buttonsuma";
			this->buttonsuma->Size = System::Drawing::Size(75, 23);
			this->buttonsuma->TabIndex = 2;
			this->buttonsuma->Text = L"Suma";
			this->buttonsuma->UseVisualStyleBackColor = true;
			this->buttonsuma->Click += gcnew System::EventHandler(this, &EjemploForm::buttonsuma_Click);
			// 
			// buttondivi
			// 
			this->buttondivi->Location = System::Drawing::Point(111, 216);
			this->buttondivi->Name = L"buttondivi";
			this->buttondivi->Size = System::Drawing::Size(75, 23);
			this->buttondivi->TabIndex = 3;
			this->buttondivi->Text = L"Division";
			this->buttondivi->UseVisualStyleBackColor = true;
			// 
			// PrimerNumero
			// 
			this->PrimerNumero->Location = System::Drawing::Point(42, 31);
			this->PrimerNumero->Name = L"PrimerNumero";
			this->PrimerNumero->Size = System::Drawing::Size(96, 19);
			this->PrimerNumero->TabIndex = 4;
			this->PrimerNumero->Text = L"";
			this->PrimerNumero->TextChanged += gcnew System::EventHandler(this, &EjemploForm::PrimerNumero_TextChanged);
			// 
			// SegundoNumero
			// 
			this->SegundoNumero->Location = System::Drawing::Point(163, 31);
			this->SegundoNumero->Name = L"SegundoNumero";
			this->SegundoNumero->Size = System::Drawing::Size(101, 19);
			this->SegundoNumero->TabIndex = 5;
			this->SegundoNumero->Text = L"";
			// 
			// Respuesta
			// 
			this->Respuesta->Location = System::Drawing::Point(98, 84);
			this->Respuesta->Name = L"Respuesta";
			this->Respuesta->Size = System::Drawing::Size(98, 20);
			this->Respuesta->TabIndex = 6;
			this->Respuesta->Text = L"";
			// 
			// label1
			// 
			this->label1->AutoSize = true;
			this->label1->Location = System::Drawing::Point(50, 15);
			this->label1->Name = L"label1";
			this->label1->Size = System::Drawing::Size(76, 13);
			this->label1->TabIndex = 7;
			this->label1->Text = L"Primer Numero";
			// 
			// label2
			// 
			this->label2->AutoSize = true;
			this->label2->Location = System::Drawing::Point(160, 15);
			this->label2->Name = L"label2";
			this->label2->Size = System::Drawing::Size(90, 13);
			this->label2->TabIndex = 8;
			this->label2->Text = L"Segundo Numero";
			// 
			// label3
			// 
			this->label3->AutoSize = true;
			this->label3->Location = System::Drawing::Point(125, 68);
			this->label3->Name = L"label3";
			this->label3->Size = System::Drawing::Size(55, 13);
			this->label3->TabIndex = 9;
			this->label3->Text = L"Resultado";
			this->label3->Click += gcnew System::EventHandler(this, &EjemploForm::label3_Click);
			// 
			// EjemploForm
			// 
			this->AutoScaleDimensions = System::Drawing::SizeF(6, 13);
			this->AutoScaleMode = System::Windows::Forms::AutoScaleMode::Font;
			this->ClientSize = System::Drawing::Size(284, 262);
			this->Controls->Add(this->label3);
			this->Controls->Add(this->label2);
			this->Controls->Add(this->label1);
			this->Controls->Add(this->Respuesta);
			this->Controls->Add(this->SegundoNumero);
			this->Controls->Add(this->PrimerNumero);
			this->Controls->Add(this->buttondivi);
			this->Controls->Add(this->buttonsuma);
			this->Controls->Add(this->buttonmulti);
			this->Controls->Add(this->buttonresta);
			this->Name = L"EjemploForm";
			this->Text = L"EjemploForm";
			this->ResumeLayout(false);
			this->PerformLayout();

		}
#pragma endregion
	private: System::Void label3_Click(System::Object^  sender, System::EventArgs^  e) {
			 }
private: System::Void PrimerNumero_TextChanged(System::Object^  sender, System::EventArgs^  e) {
		 }
private: System::Void buttonsuma_Click(System::Object^  sender, System::EventArgs^  e) {
		double num1, num2, res;
		num1=System::Convert::ToInt32(PrimerNumero->Text);
		num2=System::Convert::ToInt32(SegundoNumero->Text);
		res=num1+num2;
		Respuesta->Text=System::Convert::ToString(res);
		 }
};
}
